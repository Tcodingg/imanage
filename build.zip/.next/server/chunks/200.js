"use strict";
exports.id = 200;
exports.ids = [200];
exports.modules = {

/***/ 200:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "kS": () => (/* binding */ logout),
/* harmony export */   "x4": () => (/* binding */ login)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const initialState = {
    user: {
        id: "",
        name: "",
        email: ""
    },
    isAuthenticated: false,
    error: null
};
const login = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("auth/login", async (body, { rejectWithValue  })=>{
    try {
        const { data  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post("/api/auth/login", body);
        localStorage.setItem("isAuth", true);
        return data;
    } catch (error) {
        return rejectWithValue(error.response.data.message);
    }
});
const logout = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("/auth/logout", async (_, { rejectWithValue  })=>{
    try {
        await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get("/api/auth/logout");
        localStorage.setItem("isAuth", false);
        return;
    } catch (error) {
        rejectWithValue(error.message);
    }
});
const authSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "auth",
    initialState,
    extraReducers: (builder)=>{
        //LOGIN
        builder.addCase(login.fulfilled, (state, action)=>{
            state.user = action.payload;
            state.isAuthenticated = true;
        }).addCase(login.rejected, (state, action)=>{
            console.log(action.payload);
            state.error = action.payload;
            state.isAuthenticated = false;
        })//LOGOUT
        .addCase(logout.fulfilled, (state)=>{
            state.isAuthenticated = false;
            state.user = {};
            state.error = null;
        }).addCase(logout.rejected, (state, action)=>{
            state.error = action.payload;
        });
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (authSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;