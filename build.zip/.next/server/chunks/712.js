"use strict";
exports.id = 712;
exports.ids = [712];
exports.modules = {

/***/ 3647:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HG": () => (/* binding */ updateEmployee),
/* harmony export */   "P6": () => (/* binding */ deleteEmployee),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "aU": () => (/* binding */ sortEmployees),
/* harmony export */   "fN": () => (/* binding */ getEmployees),
/* harmony export */   "r8": () => (/* binding */ createEmployee)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


axios__WEBPACK_IMPORTED_MODULE_1__["default"].defaults.withCredentials = true;
const initialState = {
    employees: [],
    isLoading: false,
    error: null,
    order: "ascending"
};
const getEmployees = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("employees/getEmployees", async (_, { rejectWithValue  })=>{
    try {
        const { data  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get("/api/employees");
        return data;
    } catch (error) {
        return rejectWithValue(error);
    }
});
const deleteEmployee = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("employees/deleteEmployee", async (id)=>{
    try {
        await axios__WEBPACK_IMPORTED_MODULE_1__["default"]["delete"](`/api/employees/delete/${id}`);
        return id;
    } catch (error) {
        return error;
    }
});
const updateEmployee = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("employees/updateEmployee", async ({ id , formData  })=>{
    try {
        const { data  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].patch(`/api/employees/update/${id}`, formData);
        return data;
    } catch (error) {
        return error;
    }
});
const createEmployee = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("employees/createEmployee", async (formData)=>{
    try {
        const { data  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post("/api/employees/create", formData);
        return data;
    } catch (error) {
        return error;
    }
});
const employeesSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "employees",
    initialState,
    reducers: {
        sortEmployees: (state, action)=>{
            return {
                ...state,
                employees: state.order === "ascending" ? [
                    ...state.employees
                ].sort((a, b)=>a[action.payload] > b[action.payload] ? 1 : -1) : [
                    ...state.employees
                ].sort((a, b)=>a[action.payload] < b[action.payload] ? 1 : -1),
                order: state.order === "ascending" ? "descending" : "ascending"
            };
        }
    },
    extraReducers: (builder)=>{
        // GET ALL EMPLOYEES
        builder.addCase(getEmployees.pending, (state)=>{
            state.isLoading = true;
        }).addCase(getEmployees.fulfilled, (state, action)=>{
            state.isLoading = false;
            state.employees = action.payload;
        }).addCase(getEmployees.rejected, (state, action)=>{
            state.isLoading = false;
            state.error = action.payload;
        })// CREATE EMPLOYEE
        .addCase(createEmployee.fulfilled, (state, action)=>{
            state.isLoading = false;
            if (!action.payload) {
                console.log("can not add employee");
                console.log(action.payload);
                return;
            }
            let newEmployee = action.payload;
            state.employees = [
                ...state.employees,
                newEmployee
            ];
        }).addCase(createEmployee.rejected, (state, action)=>{
            state.isLoading = false;
            state.error = action.payload;
        })//UPDATE EMPLOYEE
        .addCase(updateEmployee.fulfilled, (state, action)=>{
            state.isLoading = false;
            if (!action.payload) {
                console.log("update cannot be completed");
                console.log(action.payload);
            }
            state.employees = state.employees.map((employee)=>employee._id === action.payload._id ? action.payload : employee);
        })// DELETE EMPLOYEE
        .addCase(deleteEmployee.fulfilled, (state, action)=>{
            state.isLoading = false;
            if (!(action === null || action === void 0 ? void 0 : action.payload)) {
                console.log("delete can not be completed");
                console.log(action.payload);
                return;
            }
            let id = action.payload;
            console.log(id);
            const employees = state.employees.filter((employee)=>employee._id !== id);
            state.employees = employees;
        }).addCase(deleteEmployee.rejected, (state, action)=>{
            state.isLoading = false;
            state.error = action.payload;
        });
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (employeesSlice.reducer);
const { sortEmployees  } = employeesSlice.actions;

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;