"use strict";
exports.id = 744;
exports.ids = [744];
exports.modules = {

/***/ 2077:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Button = ({ label , background , width , textColor , handleClick  })=>{
    const buttonClass = `border p-3 text-center  items-center capitalize gap-4 rounded-sm ${background} ${width} ${textColor}`;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        onClick: handleClick,
        className: buttonClass,
        children: label
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Button);


/***/ }),

/***/ 911:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const CustomSelection = ({ optionsList , setSelectedOption , selectedOption , label ,  })=>{
    const { 0: isShown , 1: setIsShown  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const optionsRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        function handler(e) {
            var ref, ref1;
            if (!(optionsRef === null || optionsRef === void 0 ? void 0 : (ref = optionsRef.current) === null || ref === void 0 ? void 0 : ref.contains(e.target)) && !(inputRef === null || inputRef === void 0 ? void 0 : (ref1 = inputRef.current) === null || ref1 === void 0 ? void 0 : ref1.contains(e.target))) {
                setIsShown(false);
            }
        }
        addEventListener("mousedown", handler);
        return ()=>{
            document.removeEventListener("mousedown", handler);
        };
    }, []);
    const handleOptions = (role)=>{
        setSelectedOption(role);
        setIsShown((preVal)=>!preVal);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FormsContainer, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Label, {
                label: label
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "relative w-full",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            readOnly: true,
                            className: "border text-base rounded-sm focus:outline outline-none px-2 py-3 capitalize w-full ",
                            type: "text",
                            onClick: ()=>setIsShown(!isShown),
                            value: selectedOption,
                            ref: inputRef
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        ref: optionsRef,
                        className: `absolute bg-white border border-t-0 ${isShown ? "flex" : "hidden"} flex-col max-h-64 w-full `,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                            className: "max-h-full overflow-y-scroll z-10 bg-white",
                            children: optionsList.map((role, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    onClick: ()=>handleOptions(role),
                                    className: "capitalize p-3 hover:bg-gray-200 w-full",
                                    children: role
                                }, i))
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomSelection);
const FormsContainer = ({ children  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex flex-col gap-2 max-w-[340px]",
        children: children
    });
};
const Label = ({ label , id  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
        className: "text-gray-500 capitalize",
        htmlFor: id,
        children: label
    });


/***/ }),

/***/ 3744:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2077);
/* harmony import */ var _CustomSelection__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(911);
/* harmony import */ var react_file_base64__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8097);
/* harmony import */ var react_file_base64__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_file_base64__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4152);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_tb__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _helpers_options__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1711);
/* harmony import */ var _redux_employeesSlice__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3647);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_redux_employeesSlice__WEBPACK_IMPORTED_MODULE_8__]);
_redux_employeesSlice__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











const Form = ({ ...data })=>{
    const { action , name , setName , selectedRole , setSelectedRole , selectedEmployeeType , setSelectedEmployeeType , selectedStatus , setSelectedStatus , salary , setSalary , selectedImage , setSelectedImage , newImage , setNewImage , error , setError , id ,  } = data;
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    let validInput = name && selectedRole && salary && selectedEmployeeType && selectedStatus ? true : false;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    function handleClick(e) {
        e.preventDefault();
        if (validInput) {
            let formData = {
                id,
                selectedImage,
                name,
                selectedRole,
                selectedEmployeeType,
                selectedStatus,
                salary
            };
            action !== "create" ? dispatch((0,_redux_employeesSlice__WEBPACK_IMPORTED_MODULE_8__/* .updateEmployee */ .HG)({
                id,
                formData
            })) : dispatch((0,_redux_employeesSlice__WEBPACK_IMPORTED_MODULE_8__/* .createEmployee */ .r8)(formData));
            router.push("/");
            setError(false);
        } else {
            setError(true);
        }
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "max-w-4xl m-auto px-6 py-6",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: " w-10 h-10 flex justify-center items-center rounded-full shadow-md border hover:cursor-pointer",
                        onClick: ()=>router.back(),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_tb__WEBPACK_IMPORTED_MODULE_7__.TbArrowLeft, {
                            className: "text-gray-500 text-2xl"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "border-4 h-40 w-40 relative rounded-full mt-3 overflow-hidden flex items-center justify-center ",
                                children: newImage || selectedImage ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_9___default()), {
                                    className: "border-0 bg-white rounded-full",
                                    layout: "fill",
                                    objectFit: "cover",
                                    src: newImage ? newImage : selectedImage,
                                    alt: ""
                                }) : ""
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex flex-col ml-6 gap-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                    className: "max-w-[200px]",
                                    htmlFor: " ",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_file_base64__WEBPACK_IMPORTED_MODULE_6___default()), {
                                        type: "file",
                                        background: "red",
                                        multiple: false,
                                        onDone: ({ base64  })=>{
                                            setNewImage(base64);
                                            setSelectedImage(base64);
                                        }
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "text-gray-500 mt-5 text-sm",
                        children: "Recommended size is 256 X 256 or leave it blank."
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                className: "mt-10 flex flex-col gap-6",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FormsContainer, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Label, {
                                label: "name"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                onChange: (e)=>setName(e.target.value),
                                value: name,
                                className: "border text-base px-2 py-3 ",
                                type: "text"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomSelection__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        optionsList: _helpers_options__WEBPACK_IMPORTED_MODULE_10__/* .rolesList */ .zZ,
                        selectedOption: selectedRole,
                        setSelectedOption: setSelectedRole,
                        label: "role"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomSelection__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        optionsList: _helpers_options__WEBPACK_IMPORTED_MODULE_10__/* .employeeTypeList */ .Nd,
                        selectedOption: selectedEmployeeType,
                        setSelectedOption: setSelectedEmployeeType,
                        label: "type employee"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomSelection__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        optionsList: _helpers_options__WEBPACK_IMPORTED_MODULE_10__/* .employeeStatusList */ .Ti,
                        selectedOption: selectedStatus,
                        setSelectedOption: setSelectedStatus,
                        label: "status"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(FormsContainer, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Label, {
                                label: "salary"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                className: "border text-base px-2 py-3 appearance-none",
                                type: "text",
                                value: salary == undefined ? null : salary,
                                onChange: (e)=>setSalary(e.target.value)
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-10 flex gap-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Button__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        handleClick: handleClick,
                        label: action === "create" ? "create" : "save",
                        background: "bg-white",
                        width: "w-40"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Button__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        handleClick: ()=>router.push("/"),
                        label: "cancel",
                        background: "bg-red-400",
                        width: "w-40",
                        textColor: "text-white"
                    })
                ]
            }),
            error && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("small", {
                className: "text-red-500 text-center",
                children: [
                    "Please fill out all fields!",
                    " "
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Form);
const Label = ({ label , id  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
        className: "text-gray-500 capitalize",
        htmlFor: id,
        children: label
    });
const FormsContainer = ({ children  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex flex-col gap-2 max-w-[340px]",
        children: children
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1711:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Nd": () => (/* binding */ employeeTypeList),
/* harmony export */   "Ti": () => (/* binding */ employeeStatusList),
/* harmony export */   "zZ": () => (/* binding */ rolesList)
/* harmony export */ });
const rolesList = [
    "software engineer",
    "executive assistant",
    "accountant",
    "product manager",
    "business analyst",
    "sales representative",
    "marketing specialist",
    "human resource", 
];
const employeeTypeList = [
    "full time",
    "part time",
    "seasonal",
    "temporary",
    "freelancer", 
];
const employeeStatusList = [
    "active",
    "not active",
    "long absence",
    "terminated",
    "resigned", 
];


/***/ })

};
;