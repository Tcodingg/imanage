"use strict";
(() => {
var exports = {};
exports.id = 429;
exports.ids = [429];
exports.modules = {

/***/ 5142:
/***/ ((module) => {

module.exports = require("dotenv");

/***/ }),

/***/ 7993:
/***/ ((module) => {

module.exports = require("mysql2");

/***/ }),

/***/ 3809:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mysql2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7993);
/* harmony import */ var mysql2__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mysql2__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var dotenv__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5142);
/* harmony import */ var dotenv__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(dotenv__WEBPACK_IMPORTED_MODULE_1__);


dotenv__WEBPACK_IMPORTED_MODULE_1___default().config();
const db = mysql2__WEBPACK_IMPORTED_MODULE_0___default().createPool({
    host: process.env.MYSQL_HOST,
    database: process.env.MYSQL_DATABASE,
    user: process.env.MYSQL_USERNAME,
    password: process.env.MYSQL_PASSWORD
}).promise();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (db);


/***/ }),

/***/ 8340:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3809);
/* eslint-disable import/no-anonymous-default-export */ 
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (req, res)=>{
    const { selectedImage: image , name , selectedRole: role , selectedEmployeeType: typeEmployee , selectedStatus: status , salary ,  } = req.body;
    const sqlInsert = `INSERT INTO Employees(name, image, salary, role, status, typeEmployee ) VALUES (?,?,?,?,?,? )`;
    const values = [
        name,
        image,
        salary,
        role,
        status,
        typeEmployee
    ];
    try {
        const [results] = await _config_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"].query */ .Z.query(sqlInsert, values);
        let id = results.insertId;
        let newEmployee = await getEmployee(id);
        res.status(200).json(newEmployee);
    } catch (error) {
        res.status(400).json(error);
    }
});
const getEmployee = async (id)=>{
    const [data] = await _config_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"].query */ .Z.query("SELECT * FROM Employees WHERE _id=?", [
        id
    ]);
    return data[0];
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(8340));
module.exports = __webpack_exports__;

})();