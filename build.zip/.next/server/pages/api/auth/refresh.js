"use strict";
(() => {
var exports = {};
exports.id = 615;
exports.ids = [615];
exports.modules = {

/***/ 4802:
/***/ ((module) => {

module.exports = require("cookie");

/***/ }),

/***/ 9369:
/***/ ((module) => {

module.exports = import("jose");;

/***/ }),

/***/ 834:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var jose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9369);
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4802);
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(cookie__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jose__WEBPACK_IMPORTED_MODULE_0__]);
jose__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable import/no-anonymous-default-export */ 

const config = {
    matcher: [
        "/edit",
        "/api/employees/delete/:path*"
    ]
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (req, res)=>{
    const { cookies  } = req;
    let refreshToken = cookies.refreshToken;
    const refresh_token_secret = process.env.refresh_token;
    const access_token_secret = process.env.access_token;
    if (!refreshToken) {
        res.status(401).json({
            message: "No refresh token. Please login."
        });
        res.end();
    } else {
        try {
            const { payload  } = await (0,jose__WEBPACK_IMPORTED_MODULE_0__.jwtVerify)(refreshToken, new TextEncoder().encode(refresh_token_secret));
            const iat = Math.floor(Date.now() / 1000);
            // let date = new Date();
            // date.setTime(date.getTime() + 30 * 1000);
            // let expires = '';
            let date = new Date();
            let expires = date.setTime(date.getTime() + 60 * 60 * 1000);
            console.log(expires);
            const access_token = await new jose__WEBPACK_IMPORTED_MODULE_0__.SignJWT({
                id: payload.id
            }).setProtectedHeader({
                alg: "HS256",
                typ: "JWT"
            }).setExpirationTime("5s").setIssuedAt(iat).setNotBefore(iat).sign(new TextEncoder().encode(access_token_secret));
            const accessToken = await new jose__WEBPACK_IMPORTED_MODULE_0__.SignJWT({
                id: payload.id
            }).setProtectedHeader({
                alg: "HS256",
                typ: "JWT"
            }).setExpirationTime("5s").setIssuedAt(iat).setNotBefore(iat).sign(new TextEncoder().encode(access_token_secret));
            const serialized_access_token = (0,cookie__WEBPACK_IMPORTED_MODULE_1__.serialize)("accessToken", accessToken, {
                httpOnly: true,
                sameSite: "strict",
                path: "/",
                maxAge: expires
            });
            res.setHeader("Set-Cookie", serialized_access_token);
            res.status(200).json(access_token);
        } catch (error) {
            res.status(400).json({
                message: error.message
            });
        }
    }
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(834));
module.exports = __webpack_exports__;

})();