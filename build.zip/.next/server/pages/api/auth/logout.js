"use strict";
(() => {
var exports = {};
exports.id = 845;
exports.ids = [845];
exports.modules = {

/***/ 4802:
/***/ ((module) => {

module.exports = require("cookie");

/***/ }),

/***/ 4766:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4802);
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(cookie__WEBPACK_IMPORTED_MODULE_0__);
/* eslint-disable import/no-anonymous-default-export */ 
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (req, res)=>{
    const { cookies  } = req;
    const jwt = cookies.refreshToken;
    if (!jwt) {
        return res.json({
            message: "You already have logged out!"
        });
    } else {
        const refreshToken = (0,cookie__WEBPACK_IMPORTED_MODULE_0__.serialize)("refreshToken", null, {
            httpOnly: true,
            secure: "production" !== "development",
            sameSite: "strict",
            maxAge: -1,
            path: "/"
        });
        const accessToken = (0,cookie__WEBPACK_IMPORTED_MODULE_0__.serialize)("accessToken", null, {
            httpOnly: true,
            secure: "production" !== "development",
            sameSite: "strict",
            maxAge: -1,
            path: "/"
        });
        res.setHeader("Set-Cookie", [
            accessToken,
            refreshToken
        ]);
        res.status(200).json({
            message: "Successfully logged out!"
        });
    }
});


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(4766));
module.exports = __webpack_exports__;

})();