"use strict";
(() => {
var exports = {};
exports.id = 7;
exports.ids = [7];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 4802:
/***/ ((module) => {

module.exports = require("cookie");

/***/ }),

/***/ 5142:
/***/ ((module) => {

module.exports = require("dotenv");

/***/ }),

/***/ 7993:
/***/ ((module) => {

module.exports = require("mysql2");

/***/ }),

/***/ 9369:
/***/ ((module) => {

module.exports = import("jose");;

/***/ }),

/***/ 8567:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7096);
/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(bcrypt__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var dotenv__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5142);
/* harmony import */ var dotenv__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(dotenv__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _config_db__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3809);
/* harmony import */ var _helpers_createToken__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(889);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_helpers_createToken__WEBPACK_IMPORTED_MODULE_3__]);
_helpers_createToken__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable import/no-anonymous-default-export */ 



dotenv__WEBPACK_IMPORTED_MODULE_1___default().config();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (req, res)=>{
    const { method  } = req;
    if (method === "POST") {
        const { name , password , email  } = req.body;
        try {
            // check if the user exits, returns undefined if the users doesn't exist
            const exists = await getUser(email);
            // if a users exits, return an error message
            if (exists) return res.status(400).json("Email is already registered");
            // hash the password
            const salt = await bcrypt__WEBPACK_IMPORTED_MODULE_0___default().genSalt(10);
            const hashedPassword = await bcrypt__WEBPACK_IMPORTED_MODULE_0___default().hash(password, salt);
            const sqlInsert = `INSERT INTO Users(name,email,password ) VALUES (?,?,? )`;
            const values = [
                name,
                email,
                hashedPassword
            ];
            let [results] = await _config_db__WEBPACK_IMPORTED_MODULE_2__/* ["default"].query */ .Z.query(sqlInsert, values);
            let newUser = await getUser(email);
            //create refresh token and accessToken
            const refresh_token_secret = process.env.refresh_token;
            const access_token_secret = process.env.access_token;
            const iat = Math.floor(Date.now() / 1000);
            const expAccess = iat + 60 * 30; // access token expires in 30 minutes
            const expRefresh = iat + 60 * 60 * 60 * 24; // refresh token expires in 1 day
            const refresh_token = await (0,_helpers_createToken__WEBPACK_IMPORTED_MODULE_3__/* .createToken */ .V)(refresh_token_secret, "refreshToken", iat, expRefresh, newUser);
            const access_token = await (0,_helpers_createToken__WEBPACK_IMPORTED_MODULE_3__/* .createToken */ .V)(access_token_secret, "accessToken", iat, expAccess, newUser);
            // set headers to httpOnly cookie
            res.setHeader("Set-Cookie", [
                refresh_token,
                access_token
            ]);
            res.status(201).json(newUser);
        } catch (error) {
            res.status(500).json({
                message: error.message
            });
        }
    }
});
const getUser = async (email)=>{
    try {
        const [results] = await _config_db__WEBPACK_IMPORTED_MODULE_2__/* ["default"].query */ .Z.query("SELECT name, email FROM Users WHERE email=?", [
            email
        ]);
        return results[0];
    } catch (error) {
        return error;
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [999], () => (__webpack_exec__(8567)));
module.exports = __webpack_exports__;

})();