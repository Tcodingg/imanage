export const rolesList = [
  'software engineer',
  'executive assistant',
  'accountant',
  'product manager',
  'business analyst',
  'sales representative',
  'marketing specialist',
  'human resource',
];

export const employeeTypeList = [
  'full time',
  'part time',
  'seasonal',
  'temporary',
  'freelancer',
];

export const employeeStatusList = [
  'active',
  'not active',
  'long absence',
  'terminated',
  'resigned',
];
